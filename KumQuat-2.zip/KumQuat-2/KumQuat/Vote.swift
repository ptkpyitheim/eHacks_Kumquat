class Vote {
    
    var post: Int
    var user: Int
    var score: Int
    
    init (post: Int, user: Int, score: Int) {
        self.post = post
        self.user = user
        self.score = score
    }
}
